This project provides quick and easy video chats from one person to another.

To use the service, the "userName" field within the VideoActivity.java class (line 107) must be changed to be a unique name not used by another person in the call you are in. Besides that, this should provide the basis of a platform to have an AI look at the video feed to describe what is going on.

The foundations of this project would not have been possible without the base code from Alton09 on GitHub.
